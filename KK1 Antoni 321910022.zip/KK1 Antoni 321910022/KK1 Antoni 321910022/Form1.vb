﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim xHarga As Integer = NumericUpDown1.Value * NumericUpDown2.Value
        If NumericUpDown2.Value > 50 Then
            If CheckBox1.Checked Then xHarga *= 0.85
        End If
        If NumericUpDown2.Value > 100 Then
            If CheckBox3.Checked Then xHarga *= 0.95
        End If
        If CheckBox2.Checked = False Then xHarga += 50000
        MessageBox.Show(xHarga)

    End Sub
End Class
